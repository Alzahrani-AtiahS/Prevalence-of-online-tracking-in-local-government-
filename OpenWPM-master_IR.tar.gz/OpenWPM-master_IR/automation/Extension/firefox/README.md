# OpenWPM Client Extension

Used by the OpenWPM platform. This extension implements the OpenWPM instrumentation module (https://github.com/mozilla/openwpm-webext-instrumentation/) in a WebExtension.