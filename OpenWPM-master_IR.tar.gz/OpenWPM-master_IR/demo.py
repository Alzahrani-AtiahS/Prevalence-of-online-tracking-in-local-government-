
from automation import CommandSequence, TaskManager

# The list of sites that we wish to crawl
NUM_BROWSERS = 1
sites = [
    
     
'http://www.carlow.ie',
'http://www.cavancoco.ie/contact-us.htm',
'http://www.clarecoco.ie/your-council/contact-the-council/default.html',
'https://www.corkcoco.ie/en/contact-us-1',
'http://www.donegalcoco.ie/services/contactus/',
'https://www.dlrcoco.ie/en/contact-us',
'https://www.fingal.ie/contact-us',
'http://www.galway.ie/en/contactus/',
'https://www.kerrycoco.ie/contact-us/',
'http://kildare.ie/CountyCouncil/CustomerCare/',
'https://www.kilkennycoco.ie/eng/Contact_Us/',
'https://laois.ie/contact-us/',
'http://www.leitrimcoco.ie/eng/Contact_Us/Contact_Us/',
'http://www.longfordcoco.ie/Your-Council/Contact-Us/',
'https://www.louthcoco.ie/en/contact/louth-county-council/',
'https://www.mayo.ie/contact',
'https://www.meath.ie/council/your-council/about-meath-council/contact-us-office-locations-and-contact-details',
'https://monaghan.ie/contact/',
'https://www.offaly.ie/eng/',
'http://www.roscommoncoco.ie/en/',
'https://www.sligococo.ie/ContactUs/',
'https://www.sdcc.ie/en/services/our-council/about-us/customer-care/',
'https://www.tipperarycoco.ie/',
'http://www.westmeathcoco.ie/en/contactus/',
'https://www.wexfordcoco.ie/contact-us',
'https://www.wicklow.ie/Living/Your-Council/Customer-Care/Contact-Us',
'http://www.corkcity.ie/en/',
'http://www.dublincity.ie/contact-dublin-city-council',
'https://www.galwaycity.ie/contact-us-information/',
'https://www.limerick.ie/council/how-can-we-help/contact-us',
'https://www.waterfordcouncil.ie/departments/corporate/customer-care.htm/'


]

# Loads the default manager params
# and NUM_BROWSERS copies of the default browser params
manager_params, browser_params = TaskManager.load_default_params(NUM_BROWSERS)

# Update browser configuration (use this for per-browser settings)
for i in range(NUM_BROWSERS):
    # Record HTTP Requests and Responses
    browser_params[i]['http_instrument'] = True
    # Record cookie changes
    browser_params[i]['cookie_instrument'] = True
    # Record Navigations
    browser_params[i]['navigation_instrument'] = True
    # Record JS Web API calls
    browser_params[i]['js_instrument'] = True
    # Record the callstack of all WebRequests made
    browser_params[i]['callstack_instrument'] = True
# Launch only browser 0 headless
browser_params[0]['display_mode'] = 'headless'

# Update TaskManager configuration (use this for crawl-wide settings)
manager_params['data_directory'] = '~/Desktop/'
manager_params['log_directory'] = '~/Desktop/'

# Instantiates the measurement platform
# Commands time out by default after 60 seconds
manager = TaskManager.TaskManager(manager_params, browser_params)

# Visits the sites
for site in sites:

    # Parallelize sites over all number of browsers set above.
    command_sequence = CommandSequence.CommandSequence(
        site, reset=True,
        callback=lambda success, val=site:
        print("CommandSequence {} done".format(val)))

    # Start by visiting the page
    command_sequence.get(sleep=3, timeout=60)

    # Run commands across the three browsers (simple parallelization)
    manager.execute_command_sequence(command_sequence)

# Shuts down the browsers and waits for the data to finish logging
manager.close()
