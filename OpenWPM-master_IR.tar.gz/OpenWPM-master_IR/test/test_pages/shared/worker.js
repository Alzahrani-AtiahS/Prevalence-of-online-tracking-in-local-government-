
const request = new Request(
  'http://localtest.me:8000/test_pages/shared/test_image.png'
);

fetch(request);
