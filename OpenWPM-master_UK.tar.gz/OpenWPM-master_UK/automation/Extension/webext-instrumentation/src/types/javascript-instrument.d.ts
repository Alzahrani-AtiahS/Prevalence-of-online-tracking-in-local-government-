export {}; // this file needs to be a module
declare global {
  interface Window {
    openWpmContentScriptConfig: any;
  }
}
