//A simple script
window.test_script_loaded = true;
console.log("test script loaded");
